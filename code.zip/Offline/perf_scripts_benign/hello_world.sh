3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
3>>./log_file_benign/hello_world.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/hello_world
sleep 1s
echo -en "\n"
