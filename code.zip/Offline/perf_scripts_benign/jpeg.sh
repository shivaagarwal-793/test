3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
3>>./log_file_benign/jpeg.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/jpeg
sleep 1s
echo -en "\n"
