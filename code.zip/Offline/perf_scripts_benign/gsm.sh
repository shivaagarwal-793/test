3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ls & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses ps & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses netstat & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses who & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
3>>./log_file_benign/gsm.txt perf stat --log-fd 3 --append -e cycles,instructions,cache-references,cache-misses,branches,branch-misses pwd & ./benign_executables/gsm
sleep 1s
echo -en "\n"
