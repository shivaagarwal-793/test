#define _GNU_SOURCE 

#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define CORE_0 0
#define CORE_1 1

#define MAX_BUF 1024
#define DEBUG 1
#define MSG_Q_KEY 1234
#define MSG_SZ     128
#define MSG_TYPE_EXE 200
#define MSG_TYPE_AFFINITY_SET 201
#define PASSED 101
#define FAILED 100
#define AFFINITY_SET 501
#define AFFINITY_NOT_SET 500


typedef struct msg_buf {
    long    mtype;
    char    mtext[MSG_SZ];
} msg_buf;



int runCommand(const char *cmd_buf){
	if(DEBUG){
		printf("=============================\n");
		printf("cmd_buf: %s\n", cmd_buf);
		printf("=============================\n");
	}
	return system(cmd_buf);
}

int msg_q_open(){
	int msg_q_id;
	key_t key = MSG_Q_KEY;
	msg_q_id = msgget(key, IPC_CREAT | 0666);
	if(msg_q_id < 0){
		perror("msgget");
		exit(-1);
	}
	return msg_q_id;
}

void message_snd_int(int msg_q_id, int smsg, long msg_type){
	msg_buf sbuf;
	size_t buf_len;
	sprintf(sbuf.mtext, "%d", smsg);
	buf_len = strlen(sbuf.mtext) + 1;
	sbuf.mtype = msg_type;
	if(msgsnd(msg_q_id, &sbuf, buf_len, IPC_NOWAIT) < 0){
		printf ("%d, %ld, %s, %ld\n", msg_q_id, sbuf.mtype, sbuf.mtext, buf_len);
        perror("msgsnd");
        exit(-1);
	}
	// printf("Message: \"%s\" Sent\n", sbuf.mtext);
}

void message_rcv_int(int msg_q_id, int *rmsg, long msg_type){
	msg_buf rbuf;
	if(msgrcv(msg_q_id, &rbuf, MSG_SZ, msg_type, 0) < 0){
		perror("msgrcv");
		exit(-1);
	}
	// printf("Message: \"%s\" Recv\n", rbuf.mtext);
	*rmsg = atoi(rbuf.mtext);
}

void message_snd_string(int msg_q_id, char *smsg, long msg_type){
	msg_buf sbuf;
	size_t buf_len;
	strcpy(sbuf.mtext, smsg);
	buf_len = strlen(sbuf.mtext) + 1;
	sbuf.mtype = msg_type;
	if(msgsnd(msg_q_id, &sbuf, buf_len, IPC_NOWAIT) < 0){
		printf ("%d, %ld, %s, %ld\n", msg_q_id, sbuf.mtype, sbuf.mtext, buf_len);
        perror("msgsnd");
        exit(-1);
	}
	// printf("Message: \"%s\" Sent\n", sbuf.mtext);
}

void message_rcv_string(int msg_q_id, char* rmsg, long msg_type){
	msg_buf rbuf;
	if(msgrcv(msg_q_id, &rbuf, MSG_SZ, msg_type, 0) < 0){
		perror("msgrcv");
		exit(-1);
	}
	// printf("Message: \"%s\" Recv\n", rbuf.mtext);
	strcpy(rmsg, rbuf.mtext);
}

void msg_q_close(int msg_q_id){
	int res;
	struct msqid_ds buf;
	res = msgctl(msg_q_id, IPC_RMID, &buf);
	if(res < 0){
		perror("msgctl");
		exit(-1);
	}
}