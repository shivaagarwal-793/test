# -*- coding: utf-8 -*-
"""
Created on Sat Sep 16 20:33:43 2017

@author: N1705165D
"""
import t_statistics as t_stat
import numpy as np
import os

bin_directory = "binning_results/"

Matrix = [[0 for x in range(t_stat.num_hpc)] for y in range(t_stat.num_indicator)]

def calculate():
    if not os.path.exists(bin_directory):
        os.makedirs(bin_directory)
    with open("base.txt", "r") as base:
        benign = base.readlines()
    with open("input.txt", "r") as tar:
        target = tar.readlines()
    for b in benign:
        for t in target:
            b_name = b.split("/")[-1].split(".")[0]
            t_name = t.split("/")[-1].split(".")[0]
            data = np.loadtxt(t_stat.t_values_directory+b_name+"_"+t_name+".txt")
            for r in range(t_stat.num_indicator):
                for c in range(t_stat.num_hpc):
                    Matrix[r][c] = 0
                    if abs(data[r][c]) >= t_stat.t_critical:
                        Matrix[r][c] = 1
            np.savetxt(bin_directory+b_name+"_"+t_name+".txt", Matrix, delimiter = " ", fmt="%d")

def calculate_single(t):
    if not os.path.exists(bin_directory):
        os.makedirs(bin_directory)
    with open("base.txt", "r") as base:
        benign = base.readlines()
    for b in benign:
        b_name = b.split("/")[-1].split(".")[0]
        t_name = t.split("/")[-1].split(".")[0]
        data = np.loadtxt(t_stat.t_values_directory+b_name+"_"+t_name+".txt")
        for r in range(t_stat.num_indicator):
            for c in range(t_stat.num_hpc):
                Matrix[r][c] = 0
                if abs(data[r][c]) >= t_stat.t_critical:
                    Matrix[r][c] = 1
        np.savetxt(bin_directory+b_name+"_"+t_name+".txt", Matrix, delimiter = " ", fmt="%d")