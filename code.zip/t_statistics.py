# -*- coding: utf-8 -*-
"""
Created on Sat Sep 16 19:30:12 2017

@author: N1705165D
"""

import os
import numpy as np
import math
import sys

t_values_directory = "t_test_results/"
num_hpc = 6
num_indicator = 5

t_critical = 3.86460985 #(98, 0.0001)

Matrix = [[0 for x in range(num_hpc)] for y in range(num_indicator)]

def create_t_values():
    if not os.path.exists(t_values_directory):
        os.makedirs(t_values_directory)
    with open("base.txt", "r") as base:
        benign = base.readlines()
    with open("input.txt", "r") as tar:
        target = tar.readlines()
    loopcount = 0
    for b in benign:
        for t in target:
            loopcount += 1
            sys.stdout.write('\r')
            sys.stdout.write("[%-20s] %d%%" % ('*'*int((20*loopcount)/(len(benign)*len(target))), ((100*loopcount)/(len(benign)*len(target)))))
            sys.stdout.flush()
            b_name = b.split("/")[-1].split(".")[0]
            t_name = t.split("/")[-1].split(".")[0]
            data1 = np.loadtxt(b.strip())
            data2 = np.loadtxt(t.strip())
            for c in range(num_hpc):
                    for r in range(num_indicator):
                        dis1 = data1[:, c + r]
                        dis2 = data2[:, c + r]
                        t_val = (np.mean(dis1) - np.mean(dis2)) / (math.sqrt((np.var(dis1) + np.var(dis2))/len(dis1)))
                        Matrix[r][c] = t_val
            np.savetxt(t_values_directory+b_name+"_"+t_name+".txt", Matrix, delimiter = " ", fmt="%0.6f")

def create_t_values_single_file(t):
    if not os.path.exists(t_values_directory):
        os.makedirs(t_values_directory)
    with open("base.txt", "r") as base:
        benign = base.readlines()
    for b in benign:
        b_name = b.split("/")[-1].split(".")[0]
        t_name = t.split("/")[-1].split(".")[0]
        data1 = np.loadtxt(b.strip())
        data2 = np.loadtxt(t.strip())
        for c in range(num_hpc):
            for r in range(num_indicator):
                dis1 = data1[:, c + r]
                dis2 = data2[:, c + r]
                t_val = (np.mean(dis1) - np.mean(dis2)) / (math.sqrt((np.var(dis1) + np.var(dis2))/len(dis1)))
                Matrix[r][c] = t_val
        np.savetxt(t_values_directory+b_name+"_"+t_name+".txt", Matrix, delimiter = " ", fmt="%0.6f")