#include "cfi.h"

int main(int argc, char const *argv[]){

	int pid;
	int NUM_PROCS = sysconf(_SC_NPROCESSORS_CONF);
	int wait_pid;
	int status = 0;

	const char *exe_file_name = argv[2];
	if (NUM_PROCS < 2){
		printf("Number of Processors: %d (< 2)\n", NUM_PROCS);
		exit(-1);
	}
	printf("\nNumber of Processors : %d\n", NUM_PROCS);

	int sanity_check_pid = fork();

	cpu_set_t mask;
	CPU_ZERO(&mask);
	if (sanity_check_pid > 0){
		printf("Process running in WATCHDOG Core\n");
		int msg_q_id = msg_q_open();
		int res;
		int status;

		CPU_SET(CORE_0, &mask);
		if(sched_setaffinity(sanity_check_pid, sizeof(mask), &mask ) == -1 ){
 			printf("WARNING: Could not set CPU Affinity, continuing...\n");
 			message_snd_int(msg_q_id, AFFINITY_NOT_SET, MSG_TYPE_AFFINITY_SET);
 			exit(-1);
 		}

	 	message_snd_int(msg_q_id, AFFINITY_SET, MSG_TYPE_AFFINITY_SET);

 		wait(&status);
 		// printf("status %d, %d\n", status, WEXITSTATUS(status));
		if(WEXITSTATUS(status) == FAILED){
			printf("\nSanity check by WATCHDOG core: FAILED\n");
			// printf("The program under test is a : MALWARE\n");
			printf("Terminating execution...\n");
			exit(status);
		}else if(WEXITSTATUS(status) != PASSED){
			printf("\nSanity check by WATCHDOG core: Undefined result\n");
			printf("The program under test is a MALWARE\n");
			printf("Terminating execution...\n");
			exit(status);
		}
		printf("\nSanity check by WATCHDOG core: PASSED\n");
		// printf("The program under test is a BENIGN PROGRAM\n");
		// printf("Closing previous msg q\n");
		msg_q_close(msg_q_id);
		printf("Commencing the execution on SANITIZED core...\n\n");
		CPU_ZERO(&mask);
		int exec_pid = fork();
		if(exec_pid > 0){
			// printf("In exec parent\n");
			msg_q_id = msg_q_open();
			CPU_SET(CORE_1, &mask);
			if(sched_setaffinity(exec_pid, sizeof(mask), &mask ) == -1 ){
	 			printf("WARNING: Could not set CPU Affinity, continuing...\n");
	 			message_snd_int(msg_q_id, AFFINITY_NOT_SET, MSG_TYPE_AFFINITY_SET);
	 			exit(-1);
	 		}
	 		message_snd_int(msg_q_id, AFFINITY_SET, MSG_TYPE_AFFINITY_SET);
	 		wait(&status);
	 		exit(0);
		}else if(exec_pid == 0){
			// printf("In exec child\n");
			int msg_q_id = msg_q_open();
			int rmsg_int;
			message_rcv_int(msg_q_id, &rmsg_int, MSG_TYPE_AFFINITY_SET);
			if(rmsg_int == AFFINITY_NOT_SET){
				printf("Affinity couldn't be set by parent, exiting...\n");
				exit(FAILED);
			}else if(rmsg_int != AFFINITY_SET){
				printf("Unknown affinity  set msg by parent, exiting...\n");
				exit(FAILED);
			}
			printf("Affinity of the program under test set to SANITIZED core \n");
			printf("Commencing program execution on SANITIZED core...\n\n");			
			
			execl(argv[2], (char *)NULL);
			perror("execl");
			exit(FAILED);
		}
	}else if(sanity_check_pid == 0){
		int msg_q_id = msg_q_open();
		int rmsg_int;
		message_rcv_int(msg_q_id, &rmsg_int, MSG_TYPE_AFFINITY_SET);
		if(rmsg_int == AFFINITY_NOT_SET){
			printf("Affinity couldn't be set by parent, exiting...\n");
			exit(FAILED);
		}else if(rmsg_int != AFFINITY_SET){
			printf("Unknown affinity  set msg by parent, exiting...\n");
			exit(FAILED);
		}
		printf("Affinity of the program under test set to WATCHDOG core \n");
		printf("Commencing testing...\n");
		
		int cpu;
		cpu = sched_getcpu();
		printf("Runnning on CPU %d, [%s]\n", cpu, cpu == 0 ? "WATCHDOG" : "SANITIZED");
		// char buffer[MAX_BUF];
		// strcpy(buffer, "python ");
		// strcat(buffer, argv[1]);
		// printf("%s\n", argv[1]);
		// system(buffer);
		execlp("python", "python", argv[1], (char *)NULL);
		// execl("./test_program", (char *) NULL);
		// execl("/bin/sh", "sh", "/home/yvshri/ntu/ntu-intern/programs/control_flow_integration/script.sh", (char *) NULL);
		perror("execl");
		exit(FAILED);
	}else{
		perror("fork");
		exit(-1);
	}

	return 0;
}