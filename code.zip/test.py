# -*- coding: utf-8 -*-
"""
Created on Sat Sep 16 21:51:42 2017

@author: N1705165D
"""

import t_statistics
import binning
import analyze
import os

test_directory = "test_results/"

def model():
    with open("test_input.txt", "r") as tar:
        target = tar.readlines()
    if not os.path.exists(test_directory):
        os.makedirs(test_directory)
    for t in target:
        t_name = t.split("/")[-1].split(".")[0]
        print("\n-------------------- ")
        print("Program Under Test : " + t_name)
        print("-------------------- ")
        print("Creating t-values..")
        t_statistics.create_t_values_single_file(t)
        print("Creating bins based on t_crtitical value: %f (99.99%% Confidence)" % t_statistics.t_critical)
        binning.calculate_single(t)
        c = analyze.predict(test_directory, t)
        if c == 0:
            print("\n"+t_name + " is a "+'\033[92m'+"Benign Program"+'\033[0m')
        else:
            print("\n"+t_name + " is a "+'\033[91m'+"Malware Program"+'\033[0m')
        if c == 1:
            exit(100)
        else:
            exit(101)

if __name__ == "__main__":
    model()