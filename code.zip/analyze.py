# -*- coding: utf-8 -*-
"""
Created on Sat Sep 16 21:18:53 2017

@author: N1705165D
"""

import t_statistics as t_stat
import binning as binn
import numpy as np
import sys

threshold = 0.75

def calculate_weights():
    print("Creating Weight Matrix based on the bins..")
    Weights = [[0 for x in range(t_stat.num_hpc)] for y in range(t_stat.num_indicator)]
    with open("base.txt", "r") as base:
        benign = base.readlines()
    with open("input.txt", "r") as tar:
        target = tar.readlines()
    total_count = 0
    loopcount = 0
    for r in range(t_stat.num_indicator):
        for c in range(t_stat.num_hpc):
            count = 0
            for b in benign:
                for t in target:
                    loopcount += 1
                    sys.stdout.write('\r')
                    sys.stdout.write("[%-20s] %d%%" % ('*'*int((20*loopcount)/(len(benign)*len(target)*t_stat.num_hpc*t_stat.num_indicator)), ((100*loopcount)/(len(benign)*len(target)*t_stat.num_hpc*t_stat.num_indicator))))
                    sys.stdout.flush()
                    b_name = b.split("/")[-1].split(".")[0]
                    t_name = t.split("/")[-1].split(".")[0]
                    data = np.loadtxt(binn.bin_directory+b_name+"_"+t_name+".txt")
                    if data[r][c] == 1:
                        count = count + 1
            Weights[r][c] = count
            total_count = total_count + count
    np.savetxt("weights.txt", Weights, delimiter = " ", fmt="%d")
    print("\n=============")
    print("Weight Matrix")
    print("=============")
    print('\n'.join([''.join(['{:4}'.format(item) for item in row]) for row in Weights]))
    for r in range(t_stat.num_indicator):
        for c in range(t_stat.num_hpc):
            Weights[r][c] = float(Weights[r][c]) / float(total_count)    
    np.savetxt("normalized_weights.txt", Weights, delimiter = " ", fmt="%0.6f")
    print("==================")
    print("Sensitivity Matrix")
    print("==================")
    print('\n'.join(['\t'.join(['{:.6}'.format(item) for item in row]) for row in Weights]))

def predict(test_directory, t):
    with open("base.txt", "r") as base:
        benign = base.readlines()
    Count = [[0 for x in range(t_stat.num_hpc)] for y in range(t_stat.num_indicator)]
    t_name = t.split("/")[-1].split(".")[0]
    for r in range(t_stat.num_indicator):
        for c in range(t_stat.num_hpc):
            Count[r][c] = 0
            count = 0
            for b in benign:
                b_name = b.split("/")[-1].split(".")[0]
                data = np.loadtxt(binn.bin_directory+b_name+"_"+t_name+".txt")
                if data[r][c] == 1:
                    count = count + 1
            Count[r][c] = count
    np.savetxt(test_directory+"count_"+t_name+".txt", Count, delimiter = " ", fmt="%0.0f")
    print("=============")
    print("Count Matrix")
    print("=============")
    print('\n'.join([''.join(['{:4}'.format(item) for item in row]) for row in Count]))
    for r in range(t_stat.num_indicator):
        for c in range(t_stat.num_hpc):
            Count[r][c] = float(Count[r][c]) / float(len(benign))
    np.savetxt(test_directory+"normalized_count_"+t_name+".txt", Count, delimiter = " ", fmt="%0.6f")
    weight = np.loadtxt("normalized_weights.txt")
    result = np.matrix(np.multiply(Count, weight))
    score = result.sum()
    result = result.tolist()
    print("============")
    print("Score Matrix")
    print("============")
    print('\n'.join(['\t'.join(['{:.6}'.format(str(item)) for item in row]) for row in result]))
    np.savetxt(test_directory+"score_"+t_name+".txt", result, delimiter = " ", fmt="%0.6f")
    print("\nScore (lambda) : %0.6f" % score)
    return 0 if score < threshold else 1