# -*- coding: utf-8 -*-
"""
Created on Sat Sep 16 21:41:38 2017

@author: N1705165D
"""

import create_train_test_set as ctts
import train
import os
import time

choices = ["0", "1", "2", "3", "4"]

def print_menu():
    print("============================")
    print("1. Create Train and Test Set")
    print("2. Train Model")
    print("3. Test Model")
    print("4. Test Hello World Program")
    print("0. Exit")
    print("============================")

def print_train_test_set(files_benign, train_benign, test_benign, files_malware, train_malware, test_malware):
    print("=============")
    print("Train Dataset")
    print("=============")
    print("Benign Programs")
    print("---------------")
    count = 1
    for item in train_benign:
        print("%2d. %s" % (count, files_benign[item].split("/")[-1].split(".")[0]))
        count += 1
    print("\nMalware Programs")
    print("----------------")
    count = 1
    for item in train_malware:
        print("%2d. %s" % (count, files_malware[item].split("/")[-1].split(".")[0]))
        count += 1
    print("\n============")
    print("Test Dataset")
    print("============")
    print("Benign Programs")
    print("---------------")
    count = 1
    for item in test_benign:
        print("%2d. %s" % (count, files_benign[item].split("/")[-1].split(".")[0]))
        count += 1
    print("\nMalware Programs")
    print("----------------")
    count = 1
    for item in test_malware:
        print("%2d. %s" % (count, files_malware[item].split("/")[-1].split(".")[0]))
        count += 1
    print("\n..................................................................................................................\n")
    
def start_training(files_benign, train_benign, files_malware, train_malware):
    with open("base.txt", "w") as f:
        for item in train_benign:
            f.write(files_benign[item] + "\n")
    with open("input.txt", "w") as f:
        for item in train_malware:
            f.write(files_malware[item] + "\n")
    train.model()
    print("\n..................................................................................................................\n")

def read_executable(t):
    cat = t.split("_")[2].split("/")[0]
    name = t.split("_")[2].split("/")[1].split(".")[0]
    if cat == "benign":
        path = "./Offline/benign_executables/"
    else:
        path = "./Malware_Program/"
    executable = path + name
    return executable

def start_testing(test_benign, files_benign, test_malware, files_malware):
    with open("input.txt", "w") as f:
        for item in test_benign:
            f.write(files_benign[item] + "\n")
        for item in test_malware:
            f.write(files_malware[item] + "\n")
    with open("input.txt", "r") as tar:
        target = tar.readlines()
    case = 1
    for t in target:
        execute = read_executable(t)
        with open("test_input.txt", "w") as f:
            f.write(t)
        print('\033[96m' + "TEST CASE: "+str(case)+"\n" + '\033[0m')
        os.system("./scheduler test.py "+execute)
        print(".................................................................")
        case += 1
        time.sleep(2)
    print("\n..................................................................................................................\n")

def start_testing_normal(test_benign, files_benign):
    path_to_dump_file = "./Offline/hello_world.txt"
    execute = "./Offline/benign_executables/hello_world"
    with open("test_input.txt", "w") as f:
        f.write(path_to_dump_file)
    print('\033[96m' + "TEST CASE: Hello World\n" + '\033[0m')
    os.system("./scheduler test.py "+execute)
    print(".................................................................")

def main():
    con = True
    dataset = False
    trained = False
    while con:
        print_menu()
        ch = input("Enter a choice : ")
        if ch == "":
            print('\033[96m' + "Nothing Entered.." + '\033[0m')
            continue
        if ch not in choices:
            print('\033[96m' + "Invalid Choice..!!" + '\033[0m')
        if ch == "0":
            con = False
        if ch == "1":
            files_benign, train_benign, test_benign, files_malware, train_malware, test_malware = ctts.create()
            print_train_test_set(files_benign, train_benign, test_benign, files_malware, train_malware, test_malware)
            dataset = True
        if ch == "2":
            if dataset:
                start_training(files_benign, train_benign, files_malware, train_malware)
                trained = True
            else:
                print('\033[96m' + "Dataset Not Created..!!" + '\033[0m')
        if ch == "3":
            if trained:
                start_testing(test_benign, files_benign, test_malware, files_malware)
            else:
                print('\033[96m' + "Training Not Performed!!" + '\033[0m')
        if ch == "4":
            if trained:
                start_testing_normal(test_benign, files_benign)
            else:
                print('\033[96m' + "Training Not Performed..!!" + '\033[0m')
            
if __name__ == "__main__":
    main()
