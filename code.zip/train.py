import t_statistics
import binning
import analyze

def model():
    print("\nTraining Started..!!")
    print("Creating t-values based on benign and malware training dataset..")
    t_statistics.create_t_values()
    print("\nCreating bins based on t_crtitical value: %f (99.99%% Confidence)" % t_statistics.t_critical)
    binning.calculate()
    analyze.calculate_weights()
    print("\nTraining Complete..!!")